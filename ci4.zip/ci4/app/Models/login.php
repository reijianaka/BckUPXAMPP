<?php namespace App\Models;
use CodeIgniter\Model;

class login extends Model
{
	public function get_data($usname, $pswd)
	{
      return $this->db->table('login')
      ->where(array('usname' => $usname, 'pswd' => $pswd))
      ->get()->getRowArray();
	}

	//--------------------------------------------------------------------

}