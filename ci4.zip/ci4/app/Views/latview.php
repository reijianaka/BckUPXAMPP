<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= $title; ?></title>
</head>
<body>
	<h2><?= $title1; ?></h2>
	<h2>Test VIEWWCI4</h2>
</body>
</html>