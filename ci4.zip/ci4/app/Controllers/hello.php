<?php namespace App\Controllers;
use CodeIgniter\Controller;

class Hello extends Controller
{

	public function index()
	{
		
	$data['title'] = "Hello welcome to CI4";
	$data['title1'] = "coba CI4";
	echo view('hello_view', $data);

	}
}
?>