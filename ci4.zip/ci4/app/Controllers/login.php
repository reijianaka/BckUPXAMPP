<?php namespace App\Controllers;

use App\Models\login;

class login extends BaseController
{
	public function index()
	{
		return view('Login');
   }
   
   public function login_action() 
   {
      $nusr = new login();

      $usname = $this->request->getPost('usname');
      $pswd = $this->request->getPost('pswd');

      $cek = $nusr->get_data($usname, $pswd);

      if (($cek['usname'] == $usname) && ($cek['pswd'] == $pswd))
      {
         session()->set('usname', $cek['usname']);
         session()->set('usname', $cek['usname']);
         return redirect()->to(base_url('latview'));
      } else {
         session()->setFlashdata('gagal', 'Username / Password salah');
         return redirect()->to(base_url('Login'));
      }
   }

   public function logout() 
   {
      session()->destroy();
      return redirect()->to(base_url('login'));
   }

	//--------------------------------------------------------------------

}