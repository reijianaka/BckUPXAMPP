<?php
$a = $_POST['nama'];
$b = $_POST['npm'];
$c = $_POST['ipk'];

echo "Nama  : " .$a. "<br>";
echo "NPM	: " .$b. "<br>";
echo "ipk	: " .$c. "<br>";
echo "<br>";

if ($c < 2) {
	// code...
	echo "ipk anda : ".$c. " semangat, tingkatkan nilai";
}

if ($c >= 2 && $c < 3.5) {
	// code...
	echo "ipk anda : " .$c. " tingkatkan dan pertahankan";
}

if ($c >= 3.5 && $c <= 4) {
	// code...
	echo "ipk anda : " .$c. " pertahankan agar lulus dengan gelar cumlaude";
}

?>