<?php
$a = $_POST['nama'];
$b = $_POST['harga'];
$c = $_POST['jumlah'];

$total_bayar = $b*$c;
echo "nama barang = " .$a. "<br>";
echo "harga barang = " .$b. "<br>";
echo "jumlah barang = " .$c. "<br>";
echo "Total yang anda harus bayar = Rp." .$total_bayar. "<br>";
echo "<br>";

switch ($total_bayar) {
	case '$total_bayar<200000':
		// code...
	echo "belanja masih kurang dari Rp. 200.000 jadi total yang harus dibayarkan = Rp.".$total_bayar;
		break;
	case '$total_bayar>=200000 && $total_bayar<400000':
		// code...
	$discount = 0.1;
	$x=$total_bayar - ($discount*$total_bayar);
	echo "Karena total belanja lebih >= Rp." .$total_bayar. "maka, kami beri discount 10% menjadi Rp.".$x;
		break;
	case '$total_bayar>=400000 && $total_bayar<1000000':
		// code...
	$discount=0.2;
	$x=$total_bayar-($discount*$total_bayar);
	echo "karena total belanja anda >= Rp.", $hasilnya, " Maka kami beri diskon 20%.". $diskon."<br>";
		break;

	
	default:
		// code...
	echo "total barang melebihi batas";
		break;
}
?>