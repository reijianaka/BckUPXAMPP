<!DOCTYPE html>
<html>
<head>
	<title>require</title>
</head>
<body>
	<center><label>Program Perhitungan</label><br>
	 <form action="3bayarcase.php" method="post">
	<label>Nama Barang</label><br>
    <input type="text" name="nama"><br>
    <label>Harga Barang</label><br>
    <input type="text" name="harga"><br>
    <label>Jumlah Barang</label><br>
    <input type="text" name="jumlah"><br>
</center><br>
<center><button type="submit" name="submit">Hitung</button></center>

</body>
</html>