<?php 
require "2formbayar.php";
?>