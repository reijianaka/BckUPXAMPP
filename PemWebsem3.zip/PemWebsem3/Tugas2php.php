<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Form Inputan Data</title>
</head>
<body>
	<form action="Tugas2nilai.php" method="post">
		<div>
			<label>Nilai UTS</label><br>
			<input type="text" name="uts" placeholder="Entry UTS">
		</div>
		<div>
			<label>Nilai UAS</label><br>
			<input type="text" name="uas" placeholder="Entry UAS">
		</div>
		<div>
			<label>Nilai Tugas</label><br>
			<input type="text" name="tugas" placeholder="Entry TUGAS">
		</div>
		<div>
			<label>Presensi</label><br>
			<select type="label" name="presensi">
	<option value="0"> 0 </option>
	<option value="1"> 1 </option>
	<option value="2"> 2 </option>
	<option value="3"> 3 </option>
	<option value="4"> 4 </option>
	<option value="5"> 5 </option>
	<option value="6"> 6 </option>
	<option value="7"> 7 </option>
	<option value="8"> 8 </option>
	<option value="9"> 9 </option>
	<option value="10"> 10 </option>
	<option value="11"> 11 </option>
	<option value="12"> 12 </option>
	<option value="13"> 13 </option>
	<option value="14"> 14 </option>
			</select>
		</div>
		<div>
			<button>Submit</button>
		</div>
	</form>
</body>
</html>