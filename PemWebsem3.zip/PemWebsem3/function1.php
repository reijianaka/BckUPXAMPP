<?php
	$a = $_POST['a'];
	$b = $_POST['b'];
	$hasil;

function jumlah ($c,$d) {
	$nilai_c = $_POST['c'];
	$nilai_d = $_POST['d'];
	$hasil = $nilai_c+$nilai_d;
	return $hasil;

}
$hasil = jumlah($a,$b);
echo "hasil dari jumlah a + b = $hasil";

?>