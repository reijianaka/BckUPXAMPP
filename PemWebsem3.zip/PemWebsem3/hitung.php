<?php
$a = $_POST['nilai_a'];
$b = $_POST['nilai_b'];
$hasil;

function hitung($c, $d){
  $nilai_c = $c;
  $nilai_d = $d;
  $hasil = $nilai_c + $nilai_d;
  return $hasil;
}
$hasil = hitung($a, $b);
echo "Hasil Perhitungan ($a + $b) = $hasil";
?>
