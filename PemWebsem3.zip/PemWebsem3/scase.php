<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Parkir</title>
</head>
<body>
	<form method="get">
		<div>
		<div>
			<label>input hari</label><br>
			<input type="text" name="hari" placeholder="Input hari">
		</div>

		<div>
			<input type="submit" name="submit" value="submit">
		</div>
	</form>
</body>
</html>

<?php
$hari = $_GET['hari'];
switch ($hari) {
	case 'senin':
		// code...
	echo "hari senin";
		break;
	case 'selasa':
	echo "hari selasa";
		break;
	case 'rabu':
	echo "hari rabu";
		break;
	case 'kamis':
	echo "hari kamis";
		break;
	case 'jumat':
		// code...
	echo "hari jumat";
		break;
	case 'sabtu':
		// code...
	echo "hari sabtu";
		break;
		case 'minggu':
		// code...
	echo "hari minggu";
		break;

	default:
		// code...
	echo "salah hari, ga ada hari tersebut";
		break;
}
?>