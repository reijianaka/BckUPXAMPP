<?php
$a = $_POST['plat'];
$b = $_POST['jenis'];
$c = $_POST['member'];
$d = $_POST['jammasuk'];
$e = $_POST['jamkeluar'];

$f = $e-$d;
$g = 500+$f/60*500*0.10;
$h = 1000+$f/60*1000*0.20;
$i = 3000+$f/60*3000*0.20;
$j = 10000+$f/60*10000*0.30;

if ($c = 1 ) {
	// code...
	if ($b = 10) {
		// code...
		echo "Jenis kendaraan sepeda <hr> Lama parkir $f <hr> free charge member anda hanya harus membayarkan tarif dasar sebesar Rp.500";
	}
	elseif ($b = 20) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan motor <hr> Lama parkir $f <hr> free charge member anda hanya harus membayarkan tarif dasar sebesar Rp.1000";
	}
	elseif ($b = 30) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan mobil <hr> Lama parkir $f <hr> free charge member anda hanya harus membayarkan tarif dasar sebesar Rp.3000";
	}
	elseif ($b = 40) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan bus <hr> Lama parkir $f <hr> free charge member anda hanya harus membayarkan tarif dasar sebesar Rp.10000";
	}
}

elseif ($c = 2) {
	// code...
	if ($b = 10 and $f > 60 ) {
		// code...
		echo "Jenis kendaraan sepeda <hr> Lama parkir $f <hr> Anda harus membayarkan tarif dasar sebesar Rp.".$g;
	}
	elseif ($b = 20 and $f > 60 ) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan motor <hr> Lama parkir $f <hr> Anda harus membayarkan tarif dasar sebesar Rp.".$h;
	}
	elseif ($b = 30 and $f > 60 ) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan mobil <hr> Lama parkir $f <hr> Anda harus membayarkan tarif dasar sebesar Rp.".$i;
	}
	elseif ($b = 40 and $f > 60 ) {
		// code...
		echo "No kendaraan $a <hr> Jenis kendaraan bus <hr> Lama parkir $f <hr> Anda harus membayarkan tarif dasar sebesar Rp.".$j;
	}
}
?>