<?php 
$a = $_POST['uts'];
$b = $_POST['uas'];
$c = $_POST['tugas'];
$d = $_POST['presensi'];

$A = $a*0.25;
$B = $b*0.30;
$C = $c*0.25;
$D = $d*0.20;

$e = $A+$B+$C+$D;

 if ($d<12 ) {
  	echo " Maaf Anda dinyatakan tidak Lulus karena kurangnya kehadiran. Silahkan mengulang di semester depan! ";
  }

 
  elseif ($d>=12) {
  	if ($a = 0) { echo " Maaf Anda dinyatakan tidak Lulus karena Tidak Mengikuti UTS. Silahkan mengulang di semester depan! "; }
  	if ($b = 0) { echo " Maaf Anda dinyatakan tidak Lulus karena Tidak Mengikuti UAS. Silahkan mengulang di semester depan! "; }
  	if ($e >= 80 ) { echo "Nilai Anda = A <hr> Selamat Anda LULUS".$e; }
  	if ($e >= 65 and $e <80) { echo "Nilai Anda = B <hr> Selamat Anda LULUS"; }
  	if ($e >= 50 and $e <65) { echo "Nilai Anda = C <hr> Selamat Anda LULUS"; }
  	if ($e >= 30 and $e <50) { echo "Nilai Anda = D <hr> Selamat Anda LULUS"; }
  	if ($e >= 0 and $e <30) { echo "Nilai Anda = E <hr> Maaf Anda belum lulus, silahkan mengulang di semester depan"; }

  }
 ?>