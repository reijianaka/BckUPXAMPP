<?php
 echo "coba doang";
 echo "<br>";

 $a = 2;
 $b = 5;

 $c = $a * $b + 2;

 $d = "Frans Herjuno";
echo "nilai a = ". $a ."<br>";
echo "nilai b = ". $b ."<br>";
echo "nilai c = ". $c;
echo $d;
?>