<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Form Inputan Data</title>
</head>
<body>
	<form action="tamp91021.php" method="post">
		<div>
			<label>Nama Anda</label><br>
			<input type="text" name="nama" placeholder="Entry nama">
		</div>
		<div>
			<label>alamat anda</label><br>
			<input type="text" name="alamat" placeholder="Entry alamat">
		</div>
		<div>
			<label>Usia Anda</label><br>
			<input type="text" name="usia" placeholder="Entry alamat">
		</div>
		<div>
			<button>Submit</button>
		</div>
	</form>
</body>
</html>