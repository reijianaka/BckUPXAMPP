<?php
$a = $_POST['nama'];
$b = $_POST['alamat'];
$c = $_POST['usia'];

  if ($c>=17) {
  	echo $a. " anda sudah dewasa, jangan lupa pulang ke " .$b;
  }
  else {
  	echo $a. " usia anda masih " .$c. " silahkan pulang ke " .$b;
  }
?>