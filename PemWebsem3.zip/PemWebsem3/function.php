<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>function</title>
</head>
<body>
	<form action="function1.php" method="post">
		<div>
		<div>
			<label>angka</label><br>
			<input type="text" name="a" placeholder="Input angka">
			+
			<input type="text" name="b" placeholder="Input angka">
		</div>

		<div>
			<input type="submit" name="submit" value="submit">
		</div>
	</form>
</body>
</html>
