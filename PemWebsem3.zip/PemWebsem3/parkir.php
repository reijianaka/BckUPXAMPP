<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Parkir</title>
</head>
<body>
	<form action="parkir1.php" method="post">
		<div>
			<label>Jenis Kendaraan</label><br>
		<input type="radio" name="jenis" value="10"> sepeda 
		<input type="radio" name="jenis" value="20"> motor
		<input type="radio" name="jenis" value="30"> mobil
		<input type="radio" name="jenis" value="40"> bus
	</div>
		<div>
			<label>Plat Nomor</label><br>
			<input type="text" name="plat" placeholder="Entry Nomor kendaraan">
		</div>

		<div>
			<label>Member</label><br>
			<select type="label" name="member">
				<option value="nbsp;"></option> 
	<option value="0"> member </option> 
	<option value="1"> non-member </option>
</select>
		</div>
		<div>
			<label>Jam</label><br>
			<input type="text" name="jammasuk" placeholder="Jam Masuk">
			-
			<input type="text" name="jamkeluar" placeholder="Jam Keluar">
			</select>
		</div>
		<div>
			<button>Submit</button>
		</div>
	</form>
</body>
</html>