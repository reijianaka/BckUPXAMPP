<?php
$conn = mysqli_connect("localhost", "root", "", "kotaprov");
$resi = $_GET['kode'];
  if (mysqli_query($conn, "DELETE FROM buyer WHERE resi = '$resi'")) {
 
        echo "Record deleted successfully";
 
    } else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
    mysqli_close($conn);
?>
 
<a href="tampil.php">Tampilkan</a>
