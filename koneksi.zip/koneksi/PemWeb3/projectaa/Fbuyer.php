<?php
$con = mysqli_connect("localhost","root","","kotaprov");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>add daerah</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Tambah Daerah</label><br>
	 <form action="addb.php" method="post">
    <input type="text" name="resi" placeholder="Resi"><br>
<br>
    <input type="text" name="nama_buyer" placeholder="Nama Buyer"><br>
<br>
    <input type="text" name="pesanan" placeholder="Pesanan"><br>
<br>
	<input type="text" name="kode_pos" placeholder="Kode Pos"><br>
<br>
    <input type="text" name="kota" placeholder="Kota"><br>
<br>
<select name="prov">
			<?php
			$queri =mysqli_query($con,"SELECT provinsi FROM provinsi");
        
            while($result = mysqli_fetch_assoc($queri)){
            	$provinsi = $result['provinsi'];
            	echo "<option value='$provinsi'>
            	$provinsi
					</option>";
                }
			?>
				
		</select>

    <br>
</center><br>

<center><button type="submit" name="submit">Tambah</button></center>
	</td>
</tr></table></center>
</body>
</html>