<!DOCTYPE html>
<html>

<head>
    <title>Insert Page page</title>
</head>

<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "kotaprov");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        
        // Taking all values from the form data(input)
        $resi = $_REQUEST['resi'];
        $nama_buyer = $_REQUEST['nama_buyer'];
        $pesanan = $_REQUEST['pesanan'];
        $kode_pos = $_REQUEST['kode_pos'];
        $kota = $_REQUEST['kota'];
        $provinsi = $_REQUEST['prov'];
        
        // Performing insert query
        $sql = "INSERT INTO buyer VALUES ('$resi',
            '$nama_buyer','$pesanan','$kode_pos', '$kota','$provinsi')";
        
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";

            echo nl2br("\n$resi\n $nama_buyer\n "
                . "$pesanan\n$kode_pos\n $kota\n $provinsi");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
    <a href="Fbuyer1.php">Tambah baru</a>
    <br>
    <a href="index.php">Tampilkan</a>
</body>
</html>
