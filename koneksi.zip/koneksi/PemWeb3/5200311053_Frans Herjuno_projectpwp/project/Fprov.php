<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>add Provinsi</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Tambah Provinsi</label><br>
	 <form action="addprov.php" method="post">
    <input type="text" name="kd" placeholder="Kode"><br>
<br>
    <input type="text" name="prov" placeholder="Provinsi"><br>
</center><br>

<center><button type="submit" name="submit">Tambah</button></center>
	</td>
</tr></table></center>
</body>
</html>