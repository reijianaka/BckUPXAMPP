<!DOCTYPE html>
<html>

<head>
    <title>Insert Page page</title>
</head>

<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "kotaprov");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        
        // Taking all values from the form data(input)
        $kode = $_REQUEST['kd'];
        $kontak = $_REQUEST['ktk'];
        $nama_kota = $_REQUEST['nako'];
        $provinsi = $_REQUEST['prov'];
        
        // Performing insert query
        $sql = "INSERT INTO kota VALUES ('$kode',
            '$kontak','$nama_kota','$provinsi')";
        
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";

            echo nl2br("\n$kode\n $kontak\n "
                . "$nama_kota\n $provinsi");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
    <a href="Fkota.php">Tambah baru</a>
    <br>
    <a href="tampil.php">Tampilkan</a>
</body>
</html>
