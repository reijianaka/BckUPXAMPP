<?php
    session_start();
    $_SESSION['adm']="";
    header("location:Login.php");
    exit();
?>