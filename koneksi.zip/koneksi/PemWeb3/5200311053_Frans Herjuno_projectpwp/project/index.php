<?php
    $conn = mysqli_connect("localhost", "root", "", "kotaprov");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> 5100311053</title>
</head>
<body>
    <a href="Login.php">Login</a>
<h1>Daftar Daerah</h1>
    <h3><a href="Fkota1.php">Add Daerah</a></h3>
    
    <table border="1">
        <tr><center>
        <td>Kode</td>
        <td>Kontak</td>
        <td>Nama_Kota</td>
        <td>Provinsi</td>
        <td>Action</td>
        </center></tr>
    <?php
        $queri =mysqli_query($conn,"SELECT * FROM kota ORDER BY kode ASC");
        $row =mysqli_num_rows($queri);
        
        if($row > 0){
            $nomor = 0;
            while($result = mysqli_fetch_assoc($queri)){
                $nomor++;
                ?>
        <tr>
                <td><?php echo $result['kode']?></td>
                <td><?php echo $result['kontak']?></td>
                <td><?php echo $result['nama_kota']?></td>
                <td><?php echo $result['provinsi']?></td>
                <td><a href="edit1.php?kode=<?php echo "$result[kode]";?>">Edit</a> | <a href="delete1.php?kode=<?php echo "$result[kode]";?>" onclick="alert('Apakah yakin akan menghapus data?')" name="delete">Delete</a></td>
        </tr>
        <?php
            }
        }else{
        ?>
        <tr>
            <td colspan="3">Data Tidak Ditemukan</td>
        </tr>
    <?php
        }
    ?>
    </table>
    <br>
<h1>Daftar Provinsi</h1>
    
    <table border="1">
        <tr><center>
        <td>Kode</td>
        <td>Provinsi</td>
        </center></tr>
    <?php
        $queri =mysqli_query($conn,"select kode,provinsi from provinsi");
        $row =mysqli_num_rows($queri);
        
        if($row > 0){
            $nomor = 0;
            while($result = mysqli_fetch_assoc($queri)){
                $nomor++;
                ?>
        <tr>
                <td><?php echo $result['kode']?></td>
                <td><?php echo $result['provinsi']?></td>
        </tr>
        <?php
            }
        }else{
        }
        ?>
    </table>


</body>
</html>