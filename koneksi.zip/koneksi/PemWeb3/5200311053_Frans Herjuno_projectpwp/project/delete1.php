<?php
$conn = mysqli_connect("localhost", "root", "", "kotaprov");
$kode = $_GET['kode'];
  if (mysqli_query($conn, "DELETE FROM kota WHERE kode = '$kode'")) {
 
        echo "Record deleted successfully";
 
    } else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
    mysqli_close($conn);
?>
 
<a href="index.php">Tampilkan</a>
