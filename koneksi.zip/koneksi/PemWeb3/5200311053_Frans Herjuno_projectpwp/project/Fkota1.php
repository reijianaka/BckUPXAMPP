<?php
$con = mysqli_connect("localhost","root","","kotaprov");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>add daerah</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Tambah Daerah</label><br>
	 <form action="addk1.php" method="post">
    <input type="text" name="kd" placeholder="Kode"><br>
<br>
    <input type="text" name="ktk" placeholder="Kontak"><br>
<br>
    <input type="text" name="nako" placeholder="Nama Kota"><br>
<br>
<select name="prov">
			<?php
			$queri =mysqli_query($con,"SELECT provinsi FROM provinsi");
        
            while($result = mysqli_fetch_assoc($queri)){
            	$provinsi = $result['provinsi'];
            	echo "<option value='$provinsi'>
            	$provinsi
					</option>";
                }
			?>
				
		</select>

    <br>
</center><br>

<center><button type="submit" name="submit">Tambah</button></center>
	</td>
</tr></table></center>
</body>
</html>