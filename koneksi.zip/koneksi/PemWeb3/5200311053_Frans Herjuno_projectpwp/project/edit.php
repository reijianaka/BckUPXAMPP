<?php
$conn = mysqli_connect("localhost", "root", "", "kotaprov");
$queri =mysqli_query($conn,"SELECT * FROM kota WHERE kode='$_GET[kode]'");
$result = mysqli_fetch_assoc($queri);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>edit daerah</title>

</head>
<body>
<center><table border="1">
 <tr>
 	<td>
	<center><label>Edit Daerah</label><br>
	 <form action="" method="post">
    <input type="text"  name="kd" placeholder="Kode" value="<?php echo $result['kode']?>"><br>
<br>
    <input type="text"  name="ktk" placeholder="Kontak" value="<?php echo $result['kontak']?>"><br>
<br>
    <input type="text"  name="nako" placeholder="Nama Kota" value="<?php echo $result['nama_kota']?>"><br>
<br>
    <select name="prov">
            <?php
            $queri =mysqli_query($conn,"SELECT provinsi FROM provinsi");
        
            while($result = mysqli_fetch_assoc($queri)){
                $provinsi = $result['provinsi'];
                echo "<option value='$provinsi'>
                $provinsi
                    </option>";
                }
            ?>
                
        </select>
</center><br>

<center><button type="submit" name="update">Update</button></center>
	</td>
</tr></table></center>

<?php
	$conn = mysqli_connect("localhost", "root", "", "kotaprov");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        

 if (isset($_POST['update'])) {
     // code...
    $query = mysqli_query($conn,"UPDATE kota SET kode='$_POST[kd]', kontak='$_POST[ktk]', nama_kota='$_POST[nako]', provinsi='$_POST[prov]' WHERE kode='$_GET[kode]'");
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
else
{
    echo "Data successfully updated";
}
 }

 mysqli_close($conn);
?>
<br>
<a href="tampil.php">Tampilkan</a>




</body>
</html>