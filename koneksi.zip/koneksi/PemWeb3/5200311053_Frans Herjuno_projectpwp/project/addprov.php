<!DOCTYPE html>
<html>

<head>
    <title>add prov</title>
</head>

<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "kotaprov");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        
        // Taking all values from the form data(input)
        $kode = $_REQUEST['kd'];
        $provinsi = $_REQUEST['prov'];
        
        // Performing insert query
        $sql = "INSERT INTO provinsi VALUES ('$kode', '$provinsi')";
        
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";

            echo nl2br("\n$kode\n $provinsi");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
    <a href="Fprov.php">Tambah baru</a>
    <br>
    <a href="tampil.php">Tampilkan</a>
</body>
</html>
