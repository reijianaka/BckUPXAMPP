<?php
$conn = mysqli_connect("localhost", "root", "", "kotaprov");
$kode = $_GET['kode'];
  if (mysqli_query($conn, "DELETE FROM provinsi WHERE kode = '$kode'")) {
 
        echo "Record deleted successfully";
 
    } else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
    mysqli_close($conn);
?>
 
<a href="tampil.php">Tampilkan</a>
