<?php
$conn = mysqli_connect("localhost", "root", "", "rspweb3");
$kode = $_GET['kode'];
  if (mysqli_query($conn, "DELETE FROM kelas WHERE kelas = '$kode'")) {
 
        echo "Record deleted successfully";
 
    } else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
    mysqli_close($conn);
?>
 
<a href="tampil.php">Tampilkan</a>
