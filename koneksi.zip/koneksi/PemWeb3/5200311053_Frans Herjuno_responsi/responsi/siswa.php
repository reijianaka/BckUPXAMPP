<?php
$con = mysqli_connect("localhost","root","","rspweb3");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>add siswa</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Tambah Siswa</label><br>
	 <form action="adsis.php" method="post">
	 	   <input type="text" name="id" placeholder="id"><br>
<br>
    <input type="text" name="nama" placeholder="nama"><br>
<br>
    <input type="text" name="alamat" placeholder="alamat"><br>
<br>
 
<select name="idk">
			<option value="nbsp;"> Pilih </option>
			<?php
			$queri =mysqli_query($con,"SELECT kelas FROM kelas");
        
            while($result = mysqli_fetch_assoc($queri)){
            	$kelas = $result['kelas'];
            	echo "<option value='kelas'>
            	$kelas
					</option>";
                }
			?>
				
		</select>

    <br>
</center><br>

<center><button type="submit" name="submit">Tambah</button></center>
	</td>
</tr></table></center></form>
</body>
</html>