<?php
$conn = mysqli_connect("localhost", "root", "", "rspweb3");
$queri =mysqli_query($conn,"SELECT * FROM kelas WHERE kode='$_GET[kode]'");
$result = mysqli_fetch_assoc($queri);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>edit kelas</title>

</head>
<body>
<center><table border="1">
 <tr>
 	<td>
	<center><label>Edit kelas</label><br>
	 <form action="" method="post">
    <input type="text"  name="id" placeholder="Kode" value="<?php echo $result['id']?>"><br>
<br>
    <input type="text"  name="kelas" placeholder="Kontak" value="<?php echo $result['kelas']?>"><br>
<br>
    <input type="text"  name="wali" placeholder="Nama Kota" value="<?php echo $result['wali_kelas']?>"><br>
<br>

</center><br>

<center><button type="submit" name="update">Update</button></center>
	</td>
</tr></table></center>

<?php
	$conn = mysqli_connect("localhost", "root", "", "rspweb3");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        

 if (isset($_POST['update'])) {
     // code...
    $query = mysqli_query($conn,"UPDATE kelas SET id='$_POST[id]', kelas='$_POST[kelas]', wali_kelas='$_POST[wali]' WHERE kode='$_GET[kode]'");
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
else
{
    echo "Data successfully updated";
}
 }

 mysqli_close($conn);
?>
<br>
<a href="tampil.php">Tampilkan</a>




</body>
</html>