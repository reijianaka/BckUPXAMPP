<?php
    $conn = mysqli_connect('localhost','root','','rspweb3');
    if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

    ?>
