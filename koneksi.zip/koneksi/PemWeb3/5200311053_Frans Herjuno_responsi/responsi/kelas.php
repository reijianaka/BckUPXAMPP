<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>add Kelas</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Tambah Kelas</label><br>
	 <form action="adkls.php" method="post">
	 	<input type="text" name="id" placeholder="id"><br>
<br>
    <input type="text" name="kelas" placeholder="Kelas"><br>
<br>
    <input type="text" name="wali" placeholder="Wali Kelas"><br>
</center><br>

<center><button type="submit" name="submit">Tambah</button></center>
	</td>
</tr></table></center>
</body>
</html>