<?php
    $conn = mysqli_connect("localhost", "root", "", "rspweb3");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> 5100311053</title>
</head>
<body>
    <a href="Logout.php">Logout</a>



 <?php

 ?>
      <h1>Daftar Kelas dan Wali Kelas</h1>
    <h3><a href="kelas.php">Tambah baru</a></h3>
<table border="1">
        <tr><center>
        <td>kelas</td>
        <td>Wali Kelas</td>
        <td>Action</td>
        </center></tr>
    <?php
        $queri =mysqli_query($conn,"SELECT * FROM kelas ORDER BY id ASC");
        $row =mysqli_num_rows($queri);
        
        if($row > 0){
            $nomor = 0;
            while($result = mysqli_fetch_assoc($queri)){
                $nomor++;
                ?>
        <tr>
                <td><?php echo $result['kelas']?></td>
                <td><?php echo $result['wali_kelas']?></td>
                <td><a href="edit.php?kode=<?php echo "$result[kelas]";?>">Edit</a> | <a href="delete.php?kode=<?php echo "$result[kelas]";?>" onclick="alert('Apakah yakin akan menghapus data?')" name="delete">Delete</a></td>
        </tr>
        </tr>
        <?php
            }
        }else{
        ?>
        <tr>
            <td colspan="3">Data Tidak Ditemukan</td>
        </tr>
    <?php
        }
    ?>
    </table>
    <br>
        <h1>Daftar Siswa</h1><br>
         <center><form action="search.php" method="post">
           <input type="text" name="search" placeholder="Search by nama siswa">
<button type="submit" name="submit">Search</button>
 </form></center>
    <h3><a href="siswa.php">Add Siswa</a></h3>
    
    <table border="1">
        <tr><center>
        <td>Nama</td>
        <td>Alamat</td>
        <td>Kelas</td>
        <td>Action</td>
        </center></tr>
    <?php
        $queri =mysqli_query($conn,"SELECT * FROM siswa ORDER BY id ASC");
        $row =mysqli_num_rows($queri);
        
        if($row > 0){
            $nomor = 0;
            while($result = mysqli_fetch_assoc($queri)){
                $nomor++;
                ?>
        <tr>
                <td><?php echo $result['nama']?></td>
                <td><?php echo $result['alamat']?></td>
                <td><?php echo $result['id_kelas']?></td>
                <td><a href="edit1.php?kode=<?php echo "$result[id]";?>">Edit</a> | <a href="delete1.php?kode=<?php echo "$result[id]";?>" onclick="alert('Apakah yakin akan menghapus data?')" name="delete">Delete</a></td>
        </tr>
        </tr>
        <?php
            }
        }else{
        ?>
        <tr>
            <td colspan="3">Data Tidak Ditemukan</td>
        </tr>
    <?php
        }
    ?>
    </table>
    <br>
</body>
</html>