<!DOCTYPE html>
<html>

<head>
    <title>add prov</title>
</head>

<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "rspweb3");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        
        // Taking all values from the form data(input)
        $id = $_REQUEST['id'];
        $kelas = $_REQUEST['kelas'];
        $wali = $_REQUEST['wali'];
        
        // Performing insert query
        $sql = "INSERT INTO kelas VALUES ('$id','$kelas', '$wali')";
        
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";

            echo nl2br("\n$id\n $kelas\n $wali");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
    <a href="kelas.php">Tambah baru</a>
    <br>
    <a href="tampil.php">Tampilkan</a>
</body>
</html>
