<!DOCTYPE html>
<html>

<head>
    <title>add siswa</title>
</head>

<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "rspweb3");
        
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        
        // Taking all values from the form data(input)
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $alamat = $_REQUEST['alamat'];
        $idk = $_REQUEST['idk'];
        
        
        // Performing insert query
        $sql = "INSERT INTO siswa VALUES ('id', '$nama',
            '$alamat','$idk')";
        
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";

            echo nl2br("\n$id\n $nama\n "
                . "$alamat\n $idk");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
    <a href="kelas.php">Tambah baru</a>
    <br>
    <a href="tampil.php">Tampilkan</a>
</body>
</html>
