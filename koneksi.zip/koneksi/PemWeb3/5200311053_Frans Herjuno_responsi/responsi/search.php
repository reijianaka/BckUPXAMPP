<?php
$conn =new PDO("mysql:host=localhost;dbname=rspweb3",'root','');

if (isset($_POST['submit'])) {
	// code...
	$sch = $_POST['search'];
	$scr = $conn->prepare("SELECT * FROM siswa WHERE nama = '$sch'");

	$scr->setFetchMode(PDO:: FETCH_OBJ);
	$scr->execute();

	if ($res = $scr->fetch()) {
		// code...
		?>
		<br>
		<table>
			<tr>
				<th>Nama</th>
				<th>Alamat</th>
				<th>Kelas</th>
			</tr>
			<tr>
				<td><?php echo $res->nama;?></td>
				<td><?php echo $res->alamat;?></td>
				<td><?php echo $res->id_kelas;?></td>
			</tr>
		</table>
		<?php
	}

	else{
		echo "Nama tidak ada";
	}
}
?>