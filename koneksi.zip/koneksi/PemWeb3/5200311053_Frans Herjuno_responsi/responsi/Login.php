<?php
	session_start();
        $conn = mysqli_connect("localhost", "root", "", "rspweb3");
        ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
<center><table border="1">
 <tr>
 	<td>
	<center><label>Login Admin</label><br>
	 <form method="post">
	 	<label>Username	:</label>
    <input type="text" name="usrname" placeholder="username"><br>
<br>
		<label>Password	:</label>
    <input type="password" name="passwd" placeholder="password"><br>
<br>
</center><br>

<center><button type="submit" name="login">Login</button></center>
<center><button type="submit"><a href="index.php">cancel</a></button></center>
	</td>


	<?php
		if (isset($_POST['login'])) {
			// code...
			$usrname = $_POST['usrname'];
			$passwd = $_POST['passwd'];
			$que = mysqli_query($conn, "SELECT * FROM login WHERE usrname = '$usrname' AND passwd = md5('$passwd')");
			$hsl = mysqli_num_rows($que);
			if ($hsl==1) {
				// code...
				$_SESSION['adm']=$usrname;
				header("location:tampil.php");
				exit();
			}
			else {
				echo "<br>";
				echo "Maaf username atau password invalid";
			}
		}
	?>

</body>
</html>