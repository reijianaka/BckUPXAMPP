<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>5200311053</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Harga Barang</label><br>
	 <form name="Proses"><br>
    <input type="text" name="aa" placeholder="Nama"><br>
<br>
    <input type="text" name="bb" placeholder="Jumlah"><br>
<br>
    <input type="text" name="cc" placeholder="Harga"><br>
<br>
    <input type="text" name="dd" placeholder="Total"><br>
<br>
</center><br>
<center>
<input type="button" value="Proses" onclick="hsl()"></button>
</center>
	</td></form>
	</tr></table></center>
<script>

function hsl()
{
	// code...
b=document.Proses.bb.value;
c=document.Proses.cc.value;

d=b*c;
document.Proses.dd.value=d;
}
</script>

</body>
</html>