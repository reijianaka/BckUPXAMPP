<?php
/*
class Mahasiswa
{
	 $nim;
	 $nama;
	 $prodi;

	public function biodata()
	{
		// code...
		$nim = 053;
		$nama = jun;
	 	$prodi = SI;
	}
}

	class krs extends Mahasiswa
	{
		$nim;
		$jmlmk;
		$jmlsks;


		public function setNim($nim)
		{
			$this->nim=$nim;
			// code...
		}


		public function tampilkrs(){

		 echo biodata();
		 $jmlmk = 9;
		 $jmlsks = 22;

		}
	}

		
?>*/


/**
 * 
 */
class mahasiswa
{
	public $nim;
	public $nama = "jun";
	public const prodi = "SI";

	public function biodata(){
	echo mahasiswa::nim;
	echo "<br>";
	echo mahasiswa::nama;
	echo "<br>";
	echo mahasiswa::prodi;

class krs extends Mahasiswa
	{
		$nim;
		public $jmlmk = "9";
		public $jmlsks = "22"; 

		public function tampilkrs(){

		 echo biodata();
		 echo "<br>";
		 echo krs::jmlmk;
		 echo "<br>";
		 echo krs::jmlsks;

		}
	}
}

?>

