<?php 
 
  abstract class BangunDatar{
    abstract protected function hitungLuas();
  }

  class PersegiPanjang extends BangunDatar{
    protected $p = 4;
    protected $l = 2
 
    public function hitungLuas(){
      return pow($this->p * $this->l );
    }

    //inheritance digunakan untuk memanfaatkan fitur 'code reuse' untuk menghindari duplikasi kode program.
    //override digunakan untuk mencapai run-time polymorphism.

    ?>