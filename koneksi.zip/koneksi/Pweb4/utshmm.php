<?php
class Induk {
 var $panjang;
 var $lebar;
 function luas_persegi()
 {
 $hasil= $this->panjang * $this->lebar;
 return $hasil;
 }
}
class Anak extends Induk {
 var $tinggi;
 function volume_balok()
 {
 $hasil= $this->panjang * $this->lebar * $this->tinggi;
 return $hasil;
 }
}
//object dari class Anak
$anak = new Anak;
//set nilai properti
$anak->panjang=2;
$anak->lebar=7;
$anak->tinggi=4;
//menampilkan hasil
echo "Panjang = ".$anak->panjang."<br/>";
echo "Lebar = ".$anak->lebar."<br/>";
echo "Tinggi = ".$anak->tinggi."<br/>";
echo "<br/><br/>";
echo "Hasil dari method class induk<br/>";
echo "Luas Persegi = ".$anak->luas_persegi()."<br/><br/>";
echo "Hasil dari method class anak<br/>";
echo "Volume Balok = ".$anak->volume_balok();
?> 