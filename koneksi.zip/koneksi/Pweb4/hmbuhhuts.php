<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>5200311053</title>
</head>
<body>

<center><table border="1">
 <tr>
 	<td>
	<center><label>Mahasiswa</label><br>
	 <form name="Proses" method="post"><br>
    <input type="text" name="aa" placeholder="Panjang"><br>
<br>
    <input type="text" name="bb" placeholder="Lebar"><br>
<br>
<input type="text" name="cc" placeholder="Tinggi"><br>
<br>
</center><br>
<center>
<input type="button" value="Proses" onclick="hsl()"></button>
</center>
	</td></form>
	</tr></table></center>
<script>

<?php
class Induk {
 var $panjang = $_POST['aa'];
 var $lebar = $_POST['bb'];
 function luas_persegi()
 {
 $hasil= $this->panjang * $this->lebar;
 return $hasil;
 }
}
class Anak extends Induk {
 var $tinggi = $_POST['cc'];
 function volume_balok()
 {
 $hasil= $this->panjang * $this->lebar * $this->tinggi;
 return $hasil;
 }
}
//object dari class Anak
$anak = new Anak;
//set nilai properti
$anak->$panjang;
$anak->$lebar;
$anak->$tinggi;
//menampilkan hasil
echo "Panjang = ".$anak->panjang."<br/>";
echo "Lebar = ".$anak->lebar."<br/>";
echo "Tinggi = ".$anak->tinggi."<br/>";
echo "<br/><br/>";
echo "Hasil dari method class induk<br/>";
echo "Luas Persegi = ".$anak->luas_persegi()."<br/><br/>";
echo "Hasil dari method class anak<br/>";
echo "Volume Balok = ".$anak->volume_balok();
?> 

</body>
</html>