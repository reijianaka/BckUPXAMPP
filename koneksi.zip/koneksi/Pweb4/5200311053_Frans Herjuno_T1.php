<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5200311053</title>
</head>
<body>
    <form method="post">
        <div>
            <label>Nilai UTS</label><br>
            <input type="text" name="uts">
        </div>
        <div>
            <label>Nilai UAS</label><br>
            <input type="text" name="uas">
        </div>
        <div>
            <label>Nilai Tugas</label><br>
            <input type="text" name="tgs">
        </div>
        <div>
            <button>Proses</button>
        </div>
    </form>


<?php
class Mahasiswa
{
    public $nim;
    private $nama;
	protected $uts = $_POST['uts'];
    protected $uas = $_POST['uas'];
    protected $tgs = $_POST['tgs'];
    protected $nilai;
public function __construct($nim, $nama, $uts, $uas $tgs, $nilai)
    {
        $this->nim = $nim;
        $this->nama = $nama;
        $this->uts = $uts;
        $this->uas = $uas;
        $this->tgs = $tgs;
        $this->nilai = $nilai;
    }

    protected function StatusNilai()
    {
        $a = $uts*0.30;
        $b = $uas*0.40;
        $c = $tgs*0.30;

        $nilai = $a+$b+$c;

        if ($this->nilai >= 60) {
            $status = "Lulus";
        } else {
            $status = "Gagal";
        }
        return $status;
    }

    public function BacaNama()
    {
        return $this->nama;
    }

    public function BacaNilai()
    {
        return $this->nilai;
    }
}

/**

* Class Turunan Mahasiswa dengan nama class Nilai

*/

class Nilai extends Mahasiswa
{
    public $status;

    public function BacaStatus()
    {
        $this->status = $this->StatusNilai();
        return $this->status;
    }
}

$turunan = new Nilai(053, 'jun');
echo "NIM : ".$turunan->nim."<br />";
echo "Nama : ".$turunan->BacaNama()."<br />";
echo "Nilai : ".$turunan->BacaNilai()."<br />";
echo "Status : ".$turunan->BacaStatus()."<br />";
?>
</body>
</html>