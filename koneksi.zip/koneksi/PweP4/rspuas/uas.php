<?php

class minimarket{

public $nama_barang= $_POST['nama_barang'];
public $harga= $_POST['harga'];
public $jumlah= $_POST['jumlah'];

function total($harga,$jumlah){

$this->harga = $harga;
$this->jumlah =$jumlah;

return $total = $this->harga*$this->jumlah;
}

function setnama($nama){

$this->nama = $nama;

}

function getnama(){

return $this->nama;

}

}

$beli = new minimarket();

$beli->setnama="Jun";

echo $beli->nama_barang;
echo "<br>";
echo $beli->harga;
echo "<br>";
echo $beli->jumlah;
echo "<br>";
echo $beli->total;
echo "<br>";
echo $beli->setnama;


?>