<!DOCTYPE html>
<html>
<head>
	<title>5200311053 RSP UAS</title>
</head>
<body>
	<center><label>Minimarket</label><br>
	 <form action="uas.php" method="post">
	<label>Nama Barang</label><br>
    <input type="text" name="nama_barang"><br>
    <label>Harga Barang</label><br>
    <input type="text" name="harga"><br>
    <label>Jumlah Barang</label><br>
    <input type="text" name="jumlah"><br>
</center><br>
<center><button type="submit" name="submit">Hitung</button></center>

</body>
</html>
