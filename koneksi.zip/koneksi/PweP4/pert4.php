<?php

class orang
{
	private $nama;
	private $alamat;
	private $email;

	public function __construct($namaa='nama', $alamat = 'alamat', $email = 'email')
	{
		$this->nama = $nama;
		$this->alamat = $alamat;
		$this->email = $email;
		// code...
	}

	public function info()
	{
		// code...
		$str = "$this->nama | $this->alamat | $this->email";
		return $str;
	}
}

	class mhs extends orang
	{
		private $nim;

		public function __construct($namaa='nama', $alamat = 'alamat', $email = 'email', $nim = "nim")
	{
		
	}

		public function setNim($nim)
		{
			$this->nim=$nim;
			// code...
		}

		public function info()
		{
			$str = parent::info() . " | $this->nim";
			return $str;
			// code...
		}
	}
		class dosen extends orang 
		{
			private $nip;

			public function setNip($nip)
		{
			$this->nip=$nip;
			// code...
		}

			public function info()
		{
			$str = parent::info() . " | $this->nip";
			return $str;
			// code...
		}
	}

$mhs = new mhs("Jun", "DIY", "jeje@rei.net");
$mhs->setNim("053")
echo $mhs->info();
echo '<hr>';
$dosen = new dosen("H", "DIY", "h@rei.net");
$dosen->setNip('737')
echo $dosen->info();
