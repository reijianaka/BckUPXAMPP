<?php

abstract class produk {

	private harga;
	private judul;
	private slug;

public function __construct($harga, $judul, $slug)
{
	$this->harga = $harga;
	$this->judul = $judul;
	$this->slug = $slug;
	// code...
}
protected function infoproduk()
{
	$inf = "$this->harga | $this->judul | $this->slug";
	 return $inf;

	// code...
}

}

class komik extends produk {
	private jumlahhalaman;

public function __construct($harga='harga', $judul='judul', $slug='slug', $jumlahhalaman='jumlahhalaman')
{
	// code...
}

public function setJmlhl($jumlahhalaman)
{
	$this->jumlahhalaman=$jumlahhalaman;
}

public function infoproduk()
{
	$inf = parent::infoproduk() . " | $this->jumlahhalaman";
			return $inf;
	// code...
}

}

/**
 * 
 */
class game extends produk
{
	private durasi;
	
	public function __construct($harga='harga', $judul='judul', $slug='slug', $durasi='durasi')
	{
		// code...
	}

	public function setDurasi($durasi)
	{
		$this->durasi=$durasi;
		// code...
	}

	public function infoproduk()
	{
		$inf = parent::infoproduk() . " | $this->durasi";
			return $inf;
	}
}

echo "+komik";
$komik = new komik("One Piece", "20.000", "one-piece");
$komik->setJmlhl("1000");
echo $komik->infoproduk();
echo '<hr>';
echo "+game";
$game = new game("PES 2019", "200.000", "pes-2019");
$game->setDurasi('20 jam');
echo $game->infoproduk();