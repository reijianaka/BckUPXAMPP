<?php

/**
 * 
 */
class mhs
{
	private $nim;
	public $nama;
	public const prodi = "SI";
	private $alamat;

	public function __construct($alamat)
	{
		$this->alamat = $alamat;
	}

	/*public function __destruct()
	{
		echo 'object __destruct'
	}*/

	public function setNim($nim)
	{
		// code...
		$this->nim = $nim;
	}

	public function getNim()
	{
		// code...
		return $this->nim;
	}
	public function tampil()
	{
		return $this->alamat;
	}
}

echo mhs::prodi;

echo "<br>";

$mah = new mhs("DIY");
echo $mah->tampil();
echo "<br>";
//unset($mah)

echo "<br>";

$mhs =new mhs();
$mhs->setNim("053");
echo $mhs->getNim();