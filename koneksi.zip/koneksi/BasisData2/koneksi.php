<?php
    $con = mysqli_connect('localhost','root','','article');
    if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
echo "Koneksi berhasil";

    ?>
