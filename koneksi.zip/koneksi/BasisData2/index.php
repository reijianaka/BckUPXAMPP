<?php
    require 'koneksi.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Azis Artikel</title>
</head>
<body>
    <h1>Daftar Kategori</h1>
    <h3><a href="kategori_add.php">Add Kategori</a></h3>
    <h3></h3>
    <table border="1">
        <tr>
        <td>No</td>
        <td>Category</td>
        <td>Action</td>
        </tr>
    <?php
        $queri =mysqli_query($con,"select id_kategori,nama from art_kategory");
        $row =mysqli_num_rows($queri);
        if($row > 0){
            $nomor = 0;
            while($result = mysqli_fetch_assoc($queri)){
                $nomor++;
                ?>
        <tr>
                <td><?php echo $nomor?></td>
                <td><?php echo $result['nama']?></td>
                <td><a href="detail_add.php">Add Detail Kategori</a> | <a href="proses.php?id_kategori=<?php echo $result['id_kategori'] ?>" name="delete">Delete</a></td>
        </tr>
        <?php
            }
        }else{
        ?>
        <tr>
            <td colspan="3">Data Tidak Ditemuka</td>
        </tr>
    <?php
        }
    ?>
    </table>
</body>
</html>